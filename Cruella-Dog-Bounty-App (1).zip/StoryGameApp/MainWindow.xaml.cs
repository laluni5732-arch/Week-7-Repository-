using System;
using System.IO;
using System.Windows;
using System.Windows.Media.Imaging;
namespace StoryGameApp;

public partial class MainWindow : Window
{
    // A single suspect is shared by the board, story, and contact pages.
    private record Slide(string Title, string Text, string ImagePath, string Description);
    private readonly Slide[] slides =
    {
        new("WANTED BOUNTY BOARD", "One suspect. One mission: bring the stolen dogs home.\nUse Next to read the story and reach the contacts page.", "Assets/Images/01.png", "Cruella bounty card with a $10,000 fictional reward."),
        new("ORG Mission", "The Dalmatian Rescue Bureau protects missing dogs and helps reunite them with their families. Our priority is the dogs’ safe return.\nThis case focuses on Cruella de Vil, the suspected organizer of the puppy thefts.", "Assets/Images/02.png", "Rescue mission card: protect and reunite missing dogs."),
        new("Beginning", "Pongo and Perdita’s puppies disappear from their London home. Their owners, Roger and Anita, begin searching. Reports point to Cruella de Vil and her accomplices, Jasper and Horace.", "Assets/Images/03.png", "Beginning card: Dalmatian puppies go missing."),
        new("Problem", "Cruella wants Dalmatian puppies to make a spotted fur coat. The dogs are being held at Hell Hall, and time is running out. Investigators need reliable sightings and information about the stolen dogs’ location.", "Assets/Images/04.png", "Problem card: the dogs are held at Hell Hall."),
        new("Ending", "Pongo and Perdita help rescue the puppies. The dogs escape Cruella and are reunited with Roger and Anita. The rescue becomes a new beginning for the Dalmatian family.\nThe story’s lesson: teamwork and compassion can protect those who cannot protect themselves.", "Assets/Images/05.png", "Ending card: the dogs are rescued and reunited."),
        new("Dog Owners & Support Contacts", "DOG OWNERS\nRoger & Anita — owners of Pongo and Perdita\nEmail: owners@example.com\n\nRESCUE SUPPORT / HR\nDalmatian Rescue Bureau\nPhone: 555-0101\nEmail: support@example.com\nHours: Monday–Friday, 9:00 AM–5:00 PM\n\nInclude the time, location, and description of any sighting.\nAll contacts and rewards are fictional classroom examples; this app does not send reports.", "Assets/Images/06.png", "Contacts card: dog owners and rescue support.")
    };
    private int currentSlide;
    public MainWindow() { InitializeComponent(); ShowSlide(0); }
    private void ShowSlide(int index)
    {
        if (index < 0 || index >= slides.Length) return;
        currentSlide = index;
        var slide = slides[index];
        PageTitle.Text = slide.Title;
        StoryTextBlock.Text = slide.Text;

        SlideCounter.Text = $"CASE CDV-101 / PAGE {index + 1} OF {slides.Length}";
        BackButton.IsEnabled = index > 0;
        NextButton.IsEnabled = index < slides.Length - 1;
        ImageDescription.Text = slide.Description;
        try
        {
            // Paths are relative to the app output folder, as in the starter.
            string path = Path.Combine(AppContext.BaseDirectory, slide.ImagePath);
            if (!File.Exists(path)) throw new FileNotFoundException("Image file was not found.", path);
            var image = new BitmapImage();
            image.BeginInit();
            image.CacheOption = BitmapCacheOption.OnLoad;
            image.CreateOptions = BitmapCreateOptions.IgnoreImageCache;
            image.UriSource = new Uri(path, UriKind.Absolute);
            image.EndInit();
            StoryImage.Source = image;
            StatusText.Text = "Story ready. Use Back, Next, or Restart.";
        }
        catch (Exception ex) when (ex is IOException || ex is NotSupportedException || ex is System.IO.FileFormatException)
        {
            StoryImage.Source = null;
            StatusText.Text = "Image unavailable. Check Assets/Images and the filename. " + ex.Message;
        }
    }

    private void BackButton_Click(object sender, RoutedEventArgs e) => ShowSlide(currentSlide - 1);
    private void NextButton_Click(object sender, RoutedEventArgs e) => ShowSlide(currentSlide + 1);
    private void RestartButton_Click(object sender, RoutedEventArgs e) => ShowSlide(0);
}
