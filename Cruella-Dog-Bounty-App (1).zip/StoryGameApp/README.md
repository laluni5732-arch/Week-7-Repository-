# Cruella Dog Bounty — image-based starter

The original starter structure is restored: image, story text, description, Back/Next/Restart buttons, and CapturePanel. Cruella’s six-page story remains. Artwork and bounty-card design now live in PNG files, rather than shapes embedded in XAML.

## Run
Extract the ZIP into a new folder, open StoryGameApp.csproj in Visual Studio on Windows with .NET 10 and the .NET desktop development workload, then rebuild and press F5.

## Replace images without changing code
Replace the following PNGs with your own pictures or complete screen-design images. Keep the exact filenames. Close the app, save the replacements, rebuild, and run again. Images are copied automatically on every build and loaded from the app output folder.

| Image | Page |
|---|---|
| Assets/Images/01.png | Cruella bounty / reward |
| Assets/Images/02.png | Organization mission |
| Assets/Images/03.png | Beginning |
| Assets/Images/04.png | Problem |
| Assets/Images/05.png | Ending |
| Assets/Images/06.png | Contacts |

Any PNG dimensions work; 1100 by 430 matches the included cards. The Image uses Stretch="Uniform", preserving the full picture without cropping. Story text remains separately editable.

## Adjust the screen as before
MainWindow.xaml controls Background, Foreground, StackPanel Margin, StoryImage Height/Stretch, text sizes, and button styles. MainWindow.xaml.cs contains a Slide array with Title, Text, ImagePath, and Description for each page. Change those strings to edit the story or use other image filenames. Update Description when replacing artwork. CapturePanel remains available for Week 7B; no capture features have been added.

Contacts and reward are fictional examples; no reports are sent. Story inspired by Disney’s One Hundred and One Dalmatians. Included illustrations are original code-drawn artwork. CS110 starter structure retained; adaptation prepared with ChatGPT.

## Validation
XML, click-handler references, six image paths, PNG readability, and ZIP integrity checked. Live Windows WPF build/run could not be tested here. On Windows, check Back/Next limits, Restart, and image replacement followed by rebuild. Missing images show an informative status message and leave story navigation usable.
